#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll,ll> Pr;
#define fi first
#define se second
#define mkp make_pair
#define pb emplace_back
#define popcnt __builtin_popcountll
const ll mod = 998244353;
inline ll read(){
	ll x=0, f=1; char ch=getchar();
	while(ch<'0' || ch>'9') { if(ch=='-') f=-1; ch=getchar(); }
	while(ch>='0' && ch<='9') x=x*10+ch-'0', ch=getchar();
	return x*f;
}
inline ll lg2(ll x){ return 63^__builtin_clzll(x); }
inline ll qpow(ll a,ll b){
	ll ans=1, base=a;
	while(b){
		if(b&1) ans=ans*base%mod;
		base=base*base%mod; b>>=1;
	}
	return ans;
}
void init(){ }
ll n,m; 
struct Graph{
	struct Edge{
		ll to, w, nxt;
	}edge[500005];
	ll tot, s, t, head[500005], cur[500005], dep[500005], ans;
	Graph(){
		tot = 1;
	}
	void addedgege(ll u,ll v,ll w){
		edge[++tot].to=v;
		edge[tot].w=w;
		edge[tot].nxt=head[u];
		head[u]=tot;
	}
	void add(ll u,ll v,ll w){
		addedgege(u, v, w); addedgege(v, u, 0);
	}
	bool bfs(){
		memset(dep, 0, sizeof(dep));
		memcpy(cur, head, sizeof(cur));
		queue<ll>q; q.push(s); dep[s]=1;
		while(!q.empty()){
			ll x=q.front(); q.pop();
			for(ll i=head[x]; i; i=edge[i].nxt){
				ll y=edge[i].to;
				if(!edge[i].w || dep[y]) continue;
				dep[y] = dep[x] + 1;
				q.push(y);
			}
		}
		return dep[t]>0;
	}
	ll dfs(ll x,ll flow){
		if(x==t) return flow;
		ll res = 0;
		for(ll &i=cur[x]; i && flow; i=edge[i].nxt){
			ll y=edge[i].to, val=edge[i].w;
			if(dep[y] != dep[x] + 1 || !val) continue;
			ll fl = dfs(y, min(flow, val));
			flow -= fl; res += fl;
			edge[i].w -= fl; edge[i^1].w += fl;
		}
		if(!res) dep[x] = 0;
		return res;
	}
	ll dinic(){
		ll ans=0;
		while(bfs()) ans += dfs(s, 1e18);
		return ans;
	}
}G;
void procedure(){
	n=read(), m=read(); G.s=read(), G.t=read();
	for(ll i=1;i<=m;i++){
		ll u=read(), v=read(), w=read();
		G.add(u, v, w);
	}
	printf("%lld\n", G.dinic());
}
int main(){
	ll T=1;
	init();
	while(T--) procedure();
	return 0;
}