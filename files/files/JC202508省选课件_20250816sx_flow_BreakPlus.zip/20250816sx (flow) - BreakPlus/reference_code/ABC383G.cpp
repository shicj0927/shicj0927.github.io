#include<bits/stdc++.h>
using namespace std;
#define int long long 
typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll,ll> P;
typedef vector<ll> Vc;
#define fi first
#define se second
#define mkp make_pair
#define pb emplace_back
#define popcnt __builtin_popcountll
const ll mod = 998244353;
inline ll read(){
	ll x=0, f=1; char ch=getchar();
	while(ch<'0' || ch>'9') { if(ch=='-') f=-1; ch=getchar(); }
	while(ch>='0' && ch<='9') x=x*10+ch-'0', ch=getchar();
	return x*f;
}
const ll INF = -1e18;
inline ll qpow(ll a,ll b){
	ll ans=1, base=a;
	while(b){
		if(b&1) ans=ans*base%mod;
		base=base*base%mod; b>>=1;
	}
	return ans;
}
inline ll INV(ll x){ return qpow(x, mod-2); };
int X,n,c[1200005],w[1200005];
inline Vc operator* (Vc A, Vc B){
	if(A.empty()) return B;
	if(B.empty()) return A;
	Vc res; res.resize(A.size()+B.size());
	merge(A.begin(), A.end(), B.begin(), B.end(), res.begin(), greater<ll>());
	return res;
}
inline Vc max(Vc A, Vc B){
	if(A.empty()) return B; if(B.empty()) return A;
	ll sz=max(A.size(), B.size());
	Vc res; res.resize(sz);
	for(int i=1;i<A.size();i++) A[i]+=A[i-1];
	for(int i=1;i<B.size();i++) B[i]+=B[i-1];
	for(int i=0;i<sz;i++){
		res[i]=INF;
		if(i<A.size()) res[i]=max(res[i],A[i]);
		if(i<B.size()) res[i]=max(res[i],B[i]);
	}
	for(int i=sz-1;i>=1;i--) res[i]=res[i]-res[i-1];
	return res; 
}
Vc f[6][6][400005];

int tim;
int solve(int l,int r){
	int id = (++tim);
	if(l==r){
		if(X==1) f[0][0][id].pb(w[l]);
		return id;
	}
	int mid=(l+r)>>1;
	int ls = solve(l,mid), rs = solve(mid+1,r);
	for(int p=0;p<X;p++) for(int q=0;q<X;q++){
		if(p+q>r-l+1) continue;
		f[p][q][id] = f[p][0][ls] * f[0][q][rs];
		for(int k=1;k<X;k++){
			if(p+k>mid-l+1) continue;
			if(q+X-k>r-mid) continue;
			f[p][q][id] = max(f[p][q][id], f[p][k][ls] * (Vc){w[mid-k+1]} * f[X-k][q][rs]);
		}
	}
	for(int p=0;p<X;p++) for(int q=0;q<X;q++){
		vector<ll>().swap(f[p][q][ls]);
		vector<ll>().swap(f[p][q][rs]);
	}
	return id;
}
void procedure(){
	n=read(),X=read();
	for(int i=1;i<=n;i++) c[i]=read();
	for(int i=1;i<=n-X+1;i++){
		for(int j=i;j<i+X;j++) w[i]+=c[j];
	}
	int rt = solve(1,n);
	ll sum=0;
	for(auto x: f[0][0][rt]) sum += x, printf("%lld ", sum);
	puts("");
}
signed main(){
	#ifdef LOCAL
		assert(freopen("input.txt","r",stdin));
		assert(freopen("output.txt","w",stdout));
	#endif
	ll T=1;
	// math_init();
	// NTT::init();
	while(T--) procedure();
	return 0;
}