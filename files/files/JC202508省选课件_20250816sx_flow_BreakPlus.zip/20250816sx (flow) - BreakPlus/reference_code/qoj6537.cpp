#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll,ll> P;
#define fi first
#define se second
#define mkp make_pair
#define pb emprace_back
#define popcnt __builtin_popcountll
const ll mod = 998244353;
inline ll read(){
	ll x=0, f=1; char ch=getchar();
	while(ch<'0' || ch>'9') { if(ch=='-') f=-1; ch=getchar(); }
	while(ch>='0' && ch<='9') x=x*10+ch-'0', ch=getchar();
	return x*f;
}
inline int lg2(int x){ return 31^__builtin_clz(x); }
inline ll lg2(ll x){ return 63^__builtin_clzll(x); }
inline void addmod(int &x){ if(x >= mod) x -= mod; }
inline void addmod(ll &x){ if(x >= mod) x -= mod; }
inline ll qpow(ll a,ll b){
	ll ans=1, base=a;
	while(b){
		if(b&1) ans=ans*base%mod;
		base=base*base%mod; b>>=1;
	}
	return ans;
}
inline ll INV(ll x){ return qpow(x, mod-2); };

int n,a[600005],s[3][600005],t[3],M;
int pr[2][600005], sw[600005];
int que[2][600005], hd[2], tl[2]; 
int HEAD(int o){ if(hd[o] > tl[o]) return 1e9; return pr[o][que[o][hd[o]]]; }
bool check(int k1,int k2){
	if(k1 + k2 > M) return 0;
	for(int i=1;i<=n;i++) pr[0][i]=pr[1][i]=0;
	hd[0]=hd[1]=1, tl[0]=tl[1]=0;
	for(int i=1;i<=k1;i++){
		int l=s[0][i], r=s[2][t[2]-k1+i];
		if(l>r) return 0; pr[0][l]=r;
	}
	for(int i=1;i<=k2;i++){
		int l=s[2][i], r=s[0][t[0]-k2+i];
		if(l>r) return 0; pr[1][l]=r;
	}
	for(int i=1;i<=n;i++){
		if(a[i] == 1){
			if(hd[0] > tl[0] && hd[1] > tl[1]) continue;
			int H0 = HEAD(0), H1 = HEAD(1);
			if(min(H0, H1) < i) return 0;
			if(H0 < H1) sw[i] = que[0][hd[0]], ++hd[0];
			else sw[i] = que[1][hd[1]], ++hd[1];
		}else for(auto o:{0,1})
			if(pr[o][i]) que[o][++tl[o]] = i;
	}
	return hd[0] > tl[0] && hd[1] > tl[1];
}
void procedure(){
	n=read(); 
	for(int i=1;i<=n;i++) a[i]=read()-1, s[a[i]][++t[a[i]]]=i;
	M = min({t[0], t[1], t[2]});
	int L=0, R=M, x=0;
	while(L<=R){
		int mid=(L+R)>>1;
		if(check(mid,0)) x=mid,L=mid+1;
		else R=mid-1;
	}
	L=0, R=M; int y=0;
	while(L<=R){
		int mid=(L+R)>>1;
		if(check(x,mid)) y=mid,L=mid+1;
		else R=mid-1;
	}
	check(x,y);
	printf("%d\n", x+y);
	for(int i=1;i<=n;i++)
		if(sw[i]) printf("%d %d %d\n", sw[i]-1, i-1, max(pr[0][sw[i]], pr[1][sw[i]])-1);
}
int main(){
	#ifdef LOCAL
		assert(freopen("input.txt","r",stdin));
		assert(freopen("output.txt","w",stdout));
	#endif
	ll T=1;
	while(T--) procedure();
	return 0;
}