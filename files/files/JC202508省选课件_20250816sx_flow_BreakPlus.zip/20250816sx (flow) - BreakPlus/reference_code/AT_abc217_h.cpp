#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll,ll> P;
#define fi first
#define se second
#define mkp make_pair
#define pb emplace_back
#define popcnt __builtin_popcountll
const ll mod = 998244353;
inline ll read(){
	ll x=0, f=1; char ch=getchar();
	while(ch<'0' || ch>'9') { if(ch=='-') f=-1; ch=getchar(); }
	while(ch>='0' && ch<='9') x=x*10+ch-'0', ch=getchar();
	return x*f;
}
mt19937_64 rnd(chrono::steady_clock::now().time_since_epoch().count());
ll rng(ll x,ll y){ return x+rnd()%(y-x+1); }
struct Node{
	ll val,sz,lc,rc,rk,tag;
}t[2000005]; ll id;
ll newnode(ll x){ t[++id].val=x; t[id].sz=1; t[id].rk=rnd(); return id; }
void upd(ll pos,ll v){
	if(!v) return;
	t[pos].tag += v;
	t[pos].val += v;
}
void pushdown(ll pos){
	if(t[pos].tag){
		upd(t[pos].lc, t[pos].tag);
		upd(t[pos].rc, t[pos].tag);
		t[pos].tag = 0;
	}
}
void pushup(ll pos){
	t[pos].sz = t[t[pos].lc].sz + t[t[pos].rc].sz + 1;
}
ll merge(ll a,ll b){
	if(!a || !b) return a^b;
	if(t[a].rk < t[b].rk){
		pushdown(a);
		t[a].rc = merge(t[a].rc, b);
		pushup(a); return a;
	}else{
		pushdown(b);
		t[b].lc = merge(a, t[b].lc);
		pushup(b); return b;
	}
}
void split(ll a,ll w,ll &x,ll &y){
	if(!a) { x=y=0; return; }
	pushdown(a);
	if(t[t[a].lc].sz < w){
		x = a;
		split(t[a].rc, w - t[t[a].lc].sz - 1, t[a].rc, y);
	}else{
		y = a;
		split(t[a].lc, w, x, t[a].lc);
	}
	pushup(a);
}
void divide(ll a,ll w,ll &x,ll &y){
	if(!a) { x=y=0; return; }
	pushdown(a);
	if(t[a].val < w){
		x = a;
		divide(t[a].rc, w, t[a].rc, y);
	}else{
		y = a;
		divide(t[a].lc, w, x, t[a].lc);
	}
	pushup(a);
}
ll n, v0, L, rt;
vector<ll>ret;
void out(int x){
	if(!x) return;
	pushdown(x);
	out(t[x].lc); ret.pb(t[x].val); out(t[x].rc);
}
void procedure(){
	n=read();
	L = n+1;
	for(ll i=1;i<=2*(n+1);i++) rt = merge(rt, newnode(0));
	ll lst = 0;
	for(ll i=1;i<=n;i++){
		ll a=read(), b=read(), c=read();
		ll x=0,y=0; split(rt, L, x, y);
		upd(x, lst-a); v0 += (lst-a) * L; upd(y, a-lst);
		rt = merge(x,y);
		
		if(b == 0) L ++, v0 += c;
		x=y=0; divide(rt, c, x, y);
		rt = merge(merge(x, newnode(c)), y);

		lst=a;
	}
	out(rt);
	ll cur = v0, ans = 1e18, lt = 0, sL = -L;
	for(auto x: ret){
		cur += (x - lt) * sL; sL ++;
		ans = min(ans, cur); lt = x;
	}
	printf("%lld\n", ans);
}
int main(){
	#ifdef LOCAL
		assert(freopen("input.txt","r",stdin));
		assert(freopen("output.txt","w",stdout));
	#endif
	ll T=1;
	// math_init();
	// NTT::init();
	while(T--) procedure();
	return 0;
}