#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define pb emplace_back
const int N = 5e5 + 5;
int n, q, fa[N], pos[N], dep[N], vis[N], val[N];
namespace bp {
	int col[N<<3], tag[N<<3];
	void upd(int pos,int v){
	    col[pos]=tag[pos]=v;
	}
	void pushdown(int pos){
	    if(~tag[pos]){
	        upd(pos<<1,tag[pos]);
	        upd(pos<<1|1,tag[pos]);
	        tag[pos]=-1;
	    }
	}
	void color(int l,int r,int ql,int qr,int v,int pos){
	    if(ql<=l && r<=qr){
	        upd(pos,v);
	        return;
	    }
	    int mid=(l+r)>>1; pushdown(pos);
	    if(ql<=mid) color(l,mid,ql,qr,v,pos<<1);
	    if(mid<qr) color(mid+1,r,ql,qr,v,pos<<1|1);
	}
	int query(int l,int r,int x,int pos){
	    if(l==r) return col[pos];
	    int mid=(l+r)>>1; pushdown(pos);
	    if(x<=mid) return query(l,mid,x,pos<<1);
	    else return query(mid+1,r,x,pos<<1|1);
	}
	int tfa[N], tmp[N<<1], cnt, w;
	array<int,4>seq[N<<1];

	void solve() {
		memset(tag, -1, sizeof(tag));
		for (int i = 1; i <= n; ++i) {
			tmp[++cnt] = a[i].q1, tmp[++cnt] = a[i].q2+1;
		}
		sort(tmp+1, tmp+cnt+1); cnt=unique(tmp+1, tmp+cnt+1)-(tmp+1);
	    for(int i=1;i<=n;i++){
	        a[i].q1 = lower_bound(tmp+1, tmp+cnt+1, a[i].q1)-tmp;
	        a[i].q2 = lower_bound(tmp+1, tmp+cnt+1, a[i].q2+1)-(tmp+1);
	        seq[++w] = {a[i].p1, i, a[i].q1, a[i].q2};
	        seq[++w] = {a[i].p2+1, -i, a[i].q1, a[i].q2};
	    }

	    cnt--;
	    sort(seq+1, seq+w+1);

	    for(int i=1;i<=w;i++){
	        if(seq[i][1]>0){
	            tfa[seq[i][1]]=query(1,cnt,seq[i][2],1);
	            color(1,cnt,seq[i][2],seq[i][3],seq[i][1],1);
	        }else{
	            color(1,cnt,seq[i][2],seq[i][3],tfa[-seq[i][1]],1);
	        }
	    }

	    sort(a + 1, a + n + 1, [](node x, node y) {
	        return (ll)(x.p2 - x.p1 + 1) * (x.q2 - x.q1 + 1) > (ll)(y.p2 - y.p1 + 1) * (y.q2 - y.q1 + 1);
	    });
	    for (int i = 1; i <= n; ++i) {
			pos[a[i].id] = i;
		}

	    for (int i = 1; i <= n; ++i) {
	    	fa[i] = pos[tfa[a[i].id]];
	    }
	}
}

vector<int>nd[500005];

int main() {
#ifdef LOCAL
	assert(freopen("input.txt", "r", stdin));
	assert(freopen("output.txt", "w", stdout));
#endif
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	cin >> n >> q;
	for (int i = 1; i <= n; ++i) {
		cin >> a[i].p1 >> a[i].q1 >> a[i].p2 >> a[i].q2;
		a[i].id = i;
	}
	bp::solve();
	dep[0] = -1;
	for (int i = 1; i <= n; ++i) {
		dep[i] = dep[fa[i]] + 1;
		nd[dep[i]].pb(i);
	}
	for (int i = 1; i <= q; ++i) {
		char o; int u;
		cin >> o >> u;
		if (o == '^') {
			int d = 1;
			if(vis[u]) d = -1; vis[u] ^= 1;
			while(u) {
				val[u] += d;
				u = fa[u];
			}
		} else {
			int ans = 0;
			for(auto x: nd[u]) ans += (!!val[x]);
			printf("%d\n", ans);
		}
	}
	return 0;
}