#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll,ll> P;
#define fi first
#define se second
#define mkp make_pair
#define pb emplace_back
#define popcnt __builtin_popcountll
const ll mod = 998244353;
inline ll read(){
	ll x=0, f=1; char ch=getchar();
	while(ch<'0' || ch>'9') { if(ch=='-') f=-1; ch=getchar(); }
	while(ch>='0' && ch<='9') x=x*10+ch-'0', ch=getchar();
	return x*f;
}
inline int lg2(int x){ return 31^__builtin_clz(x); }
inline ll lg2(ll x){ return 63^__builtin_clzll(x); }
inline void addmod(int &x){ if(x >= mod) x -= mod; }
inline void addmod(ll &x){ if(x >= mod) x -= mod; }
inline ll qpow(ll a,ll b){
	ll ans=1, base=a;
	while(b){
		if(b&1) ans=ans*base%mod;
		base=base*base%mod; b>>=1;
	}
	return ans;
}
inline ll INV(ll x){ return qpow(x, mod-2); };
int n,m,tg[100005],L,R; ll v0;
multiset<int>S;
vector<int>pos[100005];
// 最靠左的一条直线过点 (0,v0)，斜率为 L
// 最靠右的一条直线斜率为 R
void add(int w){ // 加入一个 |x-w|
	L--, R++; S.insert(w); S.insert(w); v0 += w;
}
void clear(int k){ // 执行操作：dp[y] = min(dp[y], dp[x] + k * |y-x|) 
	while(L<-k && S.size()) L++, v0 -= (*S.begin()), S.erase(S.begin());
		// 左边斜率 <-k 的直线被覆盖
	while(R>k && S.size()) R--, S.erase(prev(S.end()));
		// 右边斜率 >k 的直线被覆盖
}
void procedure(){
	n=read(),m=read(); ll ans=0;
	for(int i=1;i<=n;i++){
		int p=read(),s=read(),q=read(),t=read();
		if(p == q){
			ans += max(s-t, t-s);
			continue;
		}
		if(p > q) swap(p,q),swap(s,t);
		tg[p+1]++, tg[q]--;
		pos[p].pb(s); pos[q-1].pb(t);
	}
	for(int i=1;i<=m;i++){
		clear(tg[i] += tg[i-1]);
		for(auto x: pos[i]) add(x);
	}
	ll out=1e18, lst=0;
	for(auto x: S){
		v0 += (x-lst) * (L++);
		out = min(out, v0); lst = x;
	}
	printf("%lld\n", out + ans);
}
int main(){
	#ifdef LOCAL
		assert(freopen("input.txt","r",stdin));
		assert(freopen("output.txt","w",stdout));
	#endif
	ll T=1;
	// math_init();
	// NTT::init();
	while(T--) procedure();
	return 0;
}