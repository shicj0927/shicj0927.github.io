#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll,ll> P;
#define fi first
#define se second
#define mkp make_pair
#define pb emplace_back
#define popcnt __builtin_popcountll
const ll mod = 998244353;
inline ll read(){
    ll x=0, f=1; char ch=getchar();
    while(ch<'0' || ch>'9') { if(ch=='-') f=-1; ch=getchar(); }
    while(ch>='0' && ch<='9') x=x*10+ch-'0', ch=getchar();
    return x*f;
}
inline int lg2(int x){ return 31^__builtin_clz(x); }
inline ll lg2(ll x){ return 63^__builtin_clzll(x); }
inline void addmod(int &x){ if(x >= mod) x -= mod; }
inline void addmod(ll &x){ if(x >= mod) x -= mod; }
inline ll qpow(ll a,ll b){
    ll ans=1, base=a;
    while(b){
        if(b&1) ans=ans*base%mod;
        base=base*base%mod; b>>=1;
    }
    return ans;
}
inline ll INV(ll x){ return qpow(x, mod-2); };
ll n,l[200005],r[200005];
vector<P>vl[200005],vr[200005];
 
ll val[200005];
vector<pair<ll,ll>>pt;
P merge(P A, P B){
    if(A.fi == B.fi) return A.se < B.se ? A : B;
    else return A.fi > B.fi ? A : B;
}
struct S1{
    P tr[800005]; ll tag[800005];
    void upd(ll pos,ll v){ tr[pos].fi += v, tag[pos] += v; }
    void pushup(ll pos){
        tr[pos] = merge(tr[pos<<1], tr[pos<<1|1]);
    }
    void pushdown(ll pos){
        if(tag[pos]){
            upd(pos<<1, tag[pos]);
            upd(pos<<1|1, tag[pos]);
            tag[pos] = 0;
        }
    }
    void update(ll l,ll r,ll ql,ll qr,ll v,ll pos){
        if(ql>qr) return;
        if(ql<=l && r<=qr){
            upd(pos, v);
            return;
        }
        pushdown(pos);
        ll mid=(l+r)>>1;
        if(ql<=mid) update(l,mid,ql,qr,v,pos<<1);
        if(mid<qr)  update(mid+1,r,ql,qr,v,pos<<1|1);
        pushup(pos);
    }
    P query(ll l,ll r,ll ql,ll qr,ll pos){
        if(ql<=l && r<=qr) return tr[pos];
        ll mid=(l+r)>>1;
        pushdown(pos);
        if(qr<=mid) return query(l,mid,ql,qr,pos<<1);
        else if(mid<ql) return query(mid+1,r,ql,qr,pos<<1|1);
        return merge(query(l,mid,ql,qr,pos<<1), query(mid+1,r,ql,qr,pos<<1|1));
    }
    void build(ll l,ll r,ll pos){
        if(l==r){
            tr[pos]=mkp(val[l],l);
            return;
        }
        ll mid=(l+r)>>1;
        build(l,mid,pos<<1);
        build(mid+1,r,pos<<1|1);
        pushup(pos);
    }
}S;
 
const ll INF = 1e18;
struct S2{
    ll tr[800005];
    void pushup(ll pos){
        tr[pos] = min(tr[pos<<1], tr[pos<<1|1]);
    }
    void update(ll l,ll r,ll x,ll v,ll pos){
        if(l==r){
            tr[pos] = v;
            return;
        }
        ll mid=(l+r)>>1;
        if(x<=mid) update(l,mid,x,v,pos<<1);
        else update(mid+1,r,x,v,pos<<1|1);
        pushup(pos);
    }
    ll query(ll l,ll r,ll ql,ll qr,ll pos){
        if(ql<=l && r<=qr) return tr[pos];
        ll mid=(l+r)>>1;
        if(qr<=mid) return query(l,mid,ql,qr,pos<<1);
        else if(mid<ql) return query(mid+1,r,ql,qr,pos<<1|1);
        return min(query(l,mid,ql,qr,pos<<1), query(mid+1,r,ql,qr,pos<<1|1));
    }
    void build(ll l,ll r,ll pos){
        if(l==r){
            tr[pos]=INF;
            return;
        }
        ll mid=(l+r)>>1;
        build(l,mid,pos<<1);
        build(mid+1,r,pos<<1|1);
        pushup(pos);
    }
}T;
ll ans[200005], pos[200005];
void procedure(){
    n=read();
    for(ll i=1;i<=n;i++){
        l[i]=read(), r[i]=read();
        vl[l[i]].pb(r[i],i), vr[r[i]].pb(l[i],i);
    }
 
    for(ll i=1;i<=n;i++) val[i] = val[i-1] + vr[i].size();
    for(ll i=1;i<=n;i++){
        val[i] -= i; // cnt - len
        if(val[i] > 0){
            puts("-1");
            return;
        }
    }
 
    S.build(1,n,1); T.build(1,n,1);
 
    for(ll i=1;i<=n;i++){
        for(auto p: vl[i]) T.update(1,n,p.se,p.fi,1);
 
        ll nr = n+1; P sb = S.query(1,n,i,n,1);
        if(sb.fi==0) nr = sb.se;
 
        ll L=1, R=n, x=n+1, zhy=0;
        while(L<=R){
            ll mid=(L+R)>>1, q;
            if((q=T.query(1,n,1,mid,1)) <= nr){
                x=mid; zhy=q;
                R=mid-1;
            }else L=mid+1;
        }
        if(x > n) {
            puts("-1");
            return;
        }
        ans[i] = x; pos[x] = i;
        S.update(1,n,i+1,zhy-1,1,1);
        T.update(1,n,x,INF,1);
    }
    for(ll i=1;i<=n;i++) printf("%lld ", ans[i]);
    puts("");
}
int main(){
    #ifdef LOCAL
        assert(freopen("input.txt","r",stdin));
        assert(freopen("output.txt","w",stdout));
    #endif
    ll T=1;
    // math_init();
    // NTT::init();
    while(T--) procedure();
    return 0;
}