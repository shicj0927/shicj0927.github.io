// 97 pts
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll,ll> P;
#define fi first
#define se second
#define mkp make_pair
#define pb push_back
#define popcnt __builtin_popcountll
const ll mod = 998244353;
inline ll read(){
	ll x=0, f=1; char ch=getchar();
	while(ch<'0' || ch>'9') { if(ch=='-') f=-1; ch=getchar(); }
	while(ch>='0' && ch<='9') x=x*10+ch-'0', ch=getchar();
	return x*f;
}
inline ll qpow(ll a,ll b){
	ll ans=1, base=a;
	while(b){
		if(b&1) ans=ans*base%mod;
		base=base*base%mod; b>>=1;
	}
	return ans;
}
inline ll INV(ll x){ return qpow(x, mod-2); };
#pragma GCC optimize(3, "Ofast", "inline")

basic_string<pair<ll,ll>>v;
ll n,N; ll ans[2000005];

basic_string<ll>f[2000005];

multiset<pair<ll,ll>>S, T;
inline pair<ll,ll> rev(pair<ll,ll> A){ return mkp(A.se, A.fi); }
void procedure(){
	n=read();
	ll eps = n;
	for(ll i=1;i<=n;i++) v.pb(mkp(read(),0));
	for(ll i=1;i<=n;i++) v.pb(mkp(read(),1));

	for(ll o=0;o<=2*n;o++) f[o].pb(-2e9);
	sort(v.begin(), v.end());
	for(auto [x,y]: v){
		if(!y) f[eps].pb(x);
		eps += (y ? -1 : 1);
		if(y) f[eps].pb(x);
	}

	for(ll o=0;o<=2*n;o++){
		f[o].pb(2e9); S.clear(); T.clear();

		if(f[o].size() == 2) continue;
		for(ll i=1; i<f[o].size(); i++){
			S.insert(mkp(i, f[o][i]-f[o][i-1]));
			T.insert(mkp(f[o][i]-f[o][i-1], i));
		}
		ll k = f[o].size()/2 - 1;
		while(k--){
			auto [v,id] = *T.begin();
			auto it = S.find({id,v}); ans[++N] = v;
			P A = *prev(it), B = *it, C = *next(it), ok = (P){A.fi, A.se-B.se+C.se};

			S.erase(A); S.erase(B); S.erase(C);
			T.erase(rev(A)); T.erase(rev(B)); T.erase(rev(C));
			T.insert(rev(ok));
			S.insert(ok);
		}
	}
	sort(ans+1, ans+N+1);
	for(ll i=1;i<=N;i++) ans[i] += ans[i-1];
	for(ll i=1;i<=n;i++) printf("%lld ", ans[i]);
	puts("");
}
signed main(){
	#ifdef LOCAL
		assert(freopen("input.txt","r",stdin));
		assert(freopen("output.txt","w",stdout));
	#endif
	ll T=1;
	// math_init();
	// NTT::init();
	while(T--) procedure();
	return 0;
}