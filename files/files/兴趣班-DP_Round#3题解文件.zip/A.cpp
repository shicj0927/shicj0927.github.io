#include<bits/stdc++.h>
using namespace std;
#define int long long
namespace Fastio{
	#define read Fastio::readin
	#define write Fastio::writeout
	char buf[100],*p1=buf,*p2=buf;
	inline char nc(){
		if(p1==p2) p2=(p1=buf)+fread(buf,1,1,stdin);
		return *p1++;
	}
	inline int readin(){
		int ret=0,flg=1;char ch=nc();
		while(ch<'0'||ch>'9'){if(ch=='-') flg=-1;ch=nc();}
		while(ch>='0'&&ch<='9'){ret=(ret<<1)+(ret<<3)+ch-'0';ch=nc();}
		return ret*flg;
	}
	inline void out(int x){
		if(x<0) putchar('-'),x=-x;
		if(x>9) out(x/10);
		putchar(x%10+48);
	}
	inline void writeout(int x,char ch){out(x);putchar(ch);}
}
const int N=100100,inf=0x7fffffffffffffff;
int n,a[N],tot=0,h[N],dp[N],ans;
bool v[N];
struct edge{int v,nxt;}e[N<<1];
inline void add(int u,int v){e[++tot]=(edge){v,h[u]};h[u]=tot;}
inline void dfs(int id){
	v[id]=true;dp[id]=a[id];
	for(int i=h[id];i;i=e[i].nxt){
		int now=e[i].v;
		if(!v[now]){
			dfs(now);
			if(dp[now]>0) dp[id]+=dp[now];
		}
	}
}
signed main(){
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1,u,v;i<n;i++) add(u=read(),v=read()),add(v,u);
	dfs(1);
	for(int i=1;i<=n;i++) ans=max(ans,dp[i]);
	write(ans,10);
	return 0;
}
